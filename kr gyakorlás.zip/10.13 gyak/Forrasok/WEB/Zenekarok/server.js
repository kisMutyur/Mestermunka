
const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
 
const app = express();
app.use(cors());
app.use(express.json());
 

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'rock_zenekarok_70s', 
  charset: 'utf8mb4',
});
 

const KOTELEZO = ['nev'];
const OPCIONALIS = 
                    [
    'stilus_id','orszag','varos','aktiv_evek','tagok','legsikeresebb_album','kep_url',
                    ];
 
// 6. feladat
app.get('/api/zenekar',async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM zenekarok');
    res.status(200).json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ uzenet: 'Szerverhiba' });
  }
});
 
// 7. feladat
app.post('/api/ujzenekar', async (req, res) => {
  const body = req.body || {};
 
  const hianyzik = KOTELEZO.some(
    (mezo) =>
      body[mezo] === undefined ||
      body[mezo] === null ||
      String(body[mezo]).trim() === ''
  );
  if (hianyzik) {
    return res.status(400).send('Hiányos adatok');
  }
 
  const mezok = [...KOTELEZO, ...OPCIONALIS];
  const ertekek = mezok.map((m) => (body[m] === undefined ? null : body[m]));
 
  try {
    const [result] = await pool.query(
      `INSERT INTO zenekarok (${mezok.join(', ')}) VALUES (${mezok
        .map(() => '?')
        .join(', ')})`,
      ertekek
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    if (err.code === 'ER_NO_REFERENCED_ROW_2') {
      return res.status(400).send('Hiányos adatok');
    }
    console.error(err);
    res.status(500).json({ uzenet: 'Szerverhiba' });
  }
});
 
const PORT = 3000;
app.listen(PORT, () => console.log(`Szerver fut: http://localhost:${PORT}`));
 