SELECT zenekarok.id, zenekarok.nev, zenekarok.stilus_id, zenekarok.orszag, zenekarok.varos, zenekarok.aktiv_evek, zenekarok.tagok, zenekarok.legsikeresebb_album, zenekarok.kep_url FROM zenekarok INNER JOIN stilusok ON zenekarok.stilus_id = stilusok.id;
2. insert into zenekarok(id, nev, stilus_id, orszag, varos, aktiv_evek, tagok, legsikeresebb album, kep_url) values()
3. select stilus_neve from stilusok;
 